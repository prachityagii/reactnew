import React from 'react';

const HelloWorld = () => {
  return (
    <div className="hello-container">
      <h1 className="hello-text">ReactJS CI/CD Java Home Cloud</h1>
    </div>
  );
};

export default HelloWorld;
